. env.sh

eval $JAVA_CMD:./jsi.jar:./sim-jsi.jar net.jsi.ui.Investor