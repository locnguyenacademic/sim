. env.sh

eval $JAVA_CMD:./hudup-core.jar:./hudup.jar:./jsi.jar:./sim-jsi.jar net.jsi.ui.Investor