. env.sh

eval $JAVA_CMD net.rem.regression.evaluate.RegressionEvaluator