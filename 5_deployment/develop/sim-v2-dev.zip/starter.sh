. env.sh

eval $JAVA_CMD net.hudup.Starter $1